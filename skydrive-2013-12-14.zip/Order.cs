namespace TddStore.Core
{
    public class Order
    {
        
    }
}